import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;

public abstract class GenericList<T> implements Iterable<T> {

    // private fields
    private Node<T> head;
    private int length;

    // constructor to initialize an empty list
    public GenericList() {
        this.head = null;
        this.length = 0;
    }

    // abstract methods to be implemented by subclasses
    public abstract void add(T data);
    public abstract T delete();

    // Print method to print elements of the list
    public void print() {
        if (this.head == null) {
            System.out.println("Empty List");
            return;
        }
        Node<T> current = head;
        while (current != null) {
            System.out.println(current.data);
            current = current.next;
        }
    }

    // method to store and return all values in an ArrayList
    public ArrayList<T> dumpList() {
        ArrayList<T> list = new ArrayList<>();
        Node<T> current = this.head;
        while (current != null) {
            list.add(current.data);
            current = current.next;
        }
        return list;
    }

    // method to get the element at a specific index
    public T get(int index) {
        if (index < 0 || index >= this.length) {
            return null;
        }
        Node<T> current = this.head;
        for (int i = 0; i < index; i++) {
            current = current.next;
        }
        return current.data;
    }

    // method to set the element at a specific index and return the old value
    public T set(int index, T element) {
        if (index < 0 || index >= this.length) {
            return null;
        }
        Node<T> current = this.head;
        for (int i = 0; i < index; i++) {
            current = current.next;
        }
        T oldValue = current.data;
        current.data = element;
        return oldValue;
    }

    // getters and setters
    public Node<T> getHead() {
        return this.head;
    }

    public void setHead(Node<T> head) {
        this.head = head;
    }

    public int getLength() {
        return this.length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    // descending iterator (tail to head)
    public Iterator<T> descendingIterator() {
        ArrayList<T> elements = dumpList();
        return new Iterator<>() {
            int currentIndex = elements.size() - 1;

            @Override
            public boolean hasNext() {
                return currentIndex >= 0;
            }

            @Override
            public T next() {
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                return elements.get(currentIndex--);
            }
        };
    }

    // Iterator to traverse from head to tail
    @Override
    public Iterator<T> iterator() {
        return new Iterator<>() {
            Node<T> current = head;

            @Override
            public boolean hasNext() {
                return current != null;
            }

            @Override
            public T next() {
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                T data = current.data;
                current = current.next;
                return data;
            }
        };
    }

    // Method to check if the queue is empty
    public boolean isEmpty() {
        return length == 0; // Return true if length is zero
    }

    // Method to remove and return the last element of the list
    public T remove() {
        if (isEmpty()) {
            return null; // Return null if the list is empty
        }
        
        // If the list only has one element
        if (length == 1) {
            T data = head.data; // Store data of the head node
            head = null; // Set head to null since the list will be empty
            length--; // Decrease length
            return data; // Return the removed data
        }

        // If the list has more than one element
        Node<T> current = head;
        // Traverse to the second last node
        while (current.next.next != null) {
            current = current.next;
        }

        T data = current.next.data; // Store data of the last node
        current.next = null; // Remove reference to the last node
        length--; // Decrease length
        return data; // Return the removed data
    }


    // Inner class to define a Node
    public static class Node<T> {
        T data;
        Node<T> next;

        // Constructor to initialize the Node
        public Node(T data) {
            this.data = data;
            this.next = null;
        }
    }
}
