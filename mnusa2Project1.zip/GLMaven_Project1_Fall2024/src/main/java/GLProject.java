
/*
 * Author: Mohammad Nusairat
 * NetID: 672559082
 * UIC Email: mnusa2@uic.edu
 * Description: This project implements the Queue data structure as a singly linked list, 
 * following the FIFO (First In, First Out) principle. The HashMap uses the 
 * Queue data structure to handle collisions.
 * Both data structures are implemented generically, like ArrayList, allowing 
 * different types to be used when objects are instantiated.
 */
public class GLProject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome to project 1");
		
	}
}
