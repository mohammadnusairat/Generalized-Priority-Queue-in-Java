import java.util.Iterator;
import java.util.NoSuchElementException;
public class GenericQueue<T> extends GenericList<T> {
    private Node<T> tail;  // reference to the tail of the list

    // Constructor: Initializes an empty queue
    public GenericQueue() {
        super();  // Call the superclass constructor
        this.tail = null;
    }

    // Constructor: Initializes the queue with the first value
    public GenericQueue(T value) {
        Node<T> newNode = new Node<>(value);  // Create the first node
        setHead(newNode);  // Set the head to the new node
        this.tail = newNode;  // Set the tail to the same new node
        setLength(1);  // Length starts with 1
    }

    // Add a new element to the back (tail) of the queue
    @Override
    public void add(T data) {
        Node<T> newNode = new Node<>(data);  // Create a new node
        if (this.tail != null) {
            tail.next = newNode;  // Link the current tail to the new node
        }
        this.tail = newNode;  // Update the tail reference

        if (getHead() == null) {  // If the list was empty, head points to new node
            setHead(newNode);
        }

        setLength(getLength() + 1);  // Increase the length
    }

    // Delete the front (head) of the queue and return its value
    @Override
    public T delete() {
        if (getHead() == null) {  // List is empty
            return null;
        }
        T data = getHead().data;  // Get data from the head node
        setHead(getHead().next);  // Move the head to the next node

        if (getHead() == null) {  // If the list is now empty, reset tail
            this.tail = null;
        }

        setLength(getLength() - 1);  // Decrease the length
        return data;
    }

    // Enqueue: Add an element to the back of the queue
    public void enqueue(T data) {
        add(data);
    }

    // Dequeue: Remove and return the front element of the queue
    public T dequeue() {
        return delete();
    }

    // Implementing iterator
    @Override
    public Iterator<T> iterator() {
        return new Iterator<T>() {
            private Node<T> current = getHead(); // Start from the head of the queue

            @Override
            public boolean hasNext() {
                return current != null; // Check if there is a next element
            }

            @Override
            public T next() {
                if (!hasNext()) {
                    throw new NoSuchElementException("No more elements in the queue.");
                }
                T data = current.data; // Get current data
                current = current.next; // Move to the next node
                return data; // Return the data
            }
        };
    }
}
