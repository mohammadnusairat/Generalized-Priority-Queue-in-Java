import java.util.Iterator;
import java.util.NoSuchElementException;

// ReverseGLLIterator class to iterate through a generic linked list in reverse
public class ReverseGLLIterator<T> implements Iterator<T> {
    private Node<T> current; // The current node in the iteration
    private final GenericQueue<Node<T>> stack; // Stack to hold nodes for reverse iteration

    // Constructor to initialize the iterator with the head of the list
    public ReverseGLLIterator(Node<T> head) {
        stack = new GenericQueue<>(); // Create a stack
        current = head; // Start from the head
        while (current != null) {
            stack.add(current); // Add nodes to stack (to reverse order)
            current = current.next; // Move to the next node
        }
        current = stack.isEmpty() ? null : stack.remove(); // Prepare for iteration
    }

    // Checks if there is another element in the list
    @Override
    public boolean hasNext() {
        return !stack.isEmpty(); // Returns true if there are nodes in the stack
    }

    // Returns the current element and advances to the previous
    @Override
    public T next() {
        if (!hasNext()) {
            throw new NoSuchElementException("No more elements in the list.");
        }
        T data = current.data; // Store the data of the current node
        current = stack.isEmpty() ? null : stack.remove(); // Move to the previous node
        return data; // Return the data
    }

    // Inner class to define a Node
    public static class Node<T> {
        T data;
        Node<T> next;

        // Constructor to initialize the Node
        public Node(T data) {
            this.data = data;
            this.next = null;
        }
    }
}
