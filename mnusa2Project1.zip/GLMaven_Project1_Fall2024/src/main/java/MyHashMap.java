import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class MyHashMap<K, V> implements Iterable<V> {
    private final ArrayList<GenericQueue<KeyValuePair<K, V>>> map;

    public MyHashMap() {
        map = new ArrayList<>(10);
        for (int i = 0; i < 10; i++) {
            map.add(null);
        }
    }

    private static class KeyValuePair<K, V> {
        K key;
        V value;

        public KeyValuePair(K key, V value) {
            this.key = key;
            this.value = value;
        }
    }

    public void put(K key, V value) {
        int hashValue = Math.abs(key.hashCode() % 10);
        KeyValuePair<K, V> newPair = new KeyValuePair<>(key, value);

        if (map.get(hashValue) == null) {
            map.set(hashValue, new GenericQueue<>());
        }

        for (KeyValuePair<K, V> pair : map.get(hashValue)) {
            if (pair.key.equals(key)) {
                pair.value = value;
                return;
            }
        }

        map.get(hashValue).add(newPair);
    }

    public V get(K key) {
        int hashValue = Math.abs(key.hashCode() % 10);
        GenericQueue<KeyValuePair<K, V>> bucket = map.get(hashValue);

        if (bucket != null) {
            for (KeyValuePair<K, V> pair : bucket) {
                if (pair.key.equals(key)) {
                    return pair.value;
                }
            }
        }
        return null;
    }

    public boolean contains(K key) {
        return get(key) != null;
    }

    public int size() {
        int count = 0;
        for (GenericQueue<KeyValuePair<K, V>> queue : map) {
            if (queue != null) {
                count += queue.getLength();
            }
        }
        return count;
    }

    public boolean isEmpty() {
        return size() == 0;
    }

    public V replace(K key, V value) {
        int hashValue = Math.abs(key.hashCode() % 10);
        GenericQueue<KeyValuePair<K, V>> bucket = map.get(hashValue);

        if (bucket != null) {
            for (KeyValuePair<K, V> pair : bucket) {
                if (pair.key.equals(key)) {
                    V oldValue = pair.value;
                    pair.value = value;
                    return oldValue;
                }
            }
        }
        return null;
    }

    public V remove(K key) {
        int hashValue = Math.abs(key.hashCode() % 10);
        GenericQueue<KeyValuePair<K, V>> bucket = map.get(hashValue);

        if (bucket != null) {
            Iterator<KeyValuePair<K, V>> iterator = bucket.iterator();
            while (iterator.hasNext()) {
                KeyValuePair<K, V> pair = iterator.next();
                if (pair.key.equals(key)) {
                    V value = pair.value;
                    iterator.remove();
                    return value;
                }
            }
        }
        return null;
    }

    @Override
    public Iterator<V> iterator() {
        return new HMValueIterator<>(this);
    }

    private static class HMValueIterator<K, V> implements Iterator<V> {
        private final MyHashMap<K, V> hashMap;
        private int currentBucket = 0;
        private Iterator<KeyValuePair<K, V>> bucketIterator;

        public HMValueIterator(MyHashMap<K, V> hashMap) {
            this.hashMap = hashMap;
            moveToNextBucket();
        }

        private void moveToNextBucket() {
            while (currentBucket < hashMap.map.size()) {
                GenericQueue<KeyValuePair<K, V>> bucket = hashMap.map.get(currentBucket);
                if (bucket != null && bucket.iterator().hasNext()) {
                    bucketIterator = bucket.iterator();
                    return;
                }
                currentBucket++;
            }
            bucketIterator = null;
        }

        @Override
        public boolean hasNext() {
            return bucketIterator != null && bucketIterator.hasNext();
        }

        @Override
        public V next() {
            if (!hasNext()) {
                throw new NoSuchElementException("No more elements in the HashMap.");
            }
            V value = bucketIterator.next().value;
            if (!bucketIterator.hasNext()) {
                currentBucket++;
                moveToNextBucket();
            }
            return value;
        }
    }
}