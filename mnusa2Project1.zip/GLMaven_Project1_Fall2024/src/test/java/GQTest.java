import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class GQTest {
    private GenericQueue<ReverseGLLIterator.Node<Integer>> queue;

    @BeforeEach
    public void setUp() {
        queue = new GenericQueue<>();
    }

    @Test
    public void testConstructor() {
        assertTrue(queue.isEmpty(), "New queue should be empty.");
    }

    @Test
    public void testAdd() {
        ReverseGLLIterator.Node<Integer> node = new ReverseGLLIterator.Node<>(1);
        queue.add(node);
        assertFalse(queue.isEmpty(), "Queue should not be empty after adding an element.");
        assertEquals(1, queue.getLength(), "Queue length should be 1 after adding an element.");
    }

    @Test
    public void testIterator() {
        queue.add(new ReverseGLLIterator.Node<>(1));
        queue.add(new ReverseGLLIterator.Node<>(2));
        queue.add(new ReverseGLLIterator.Node<>(3));

        List<Integer> values = new ArrayList<>();
        for (ReverseGLLIterator.Node<Integer> node : queue) {
            values.add(node.data);
        }

        assertEquals(3, values.size(), "Iterator should return three nodes.");
        assertTrue(values.contains(1));
        assertTrue(values.contains(2));
        assertTrue(values.contains(3));
    }

    @Test
    public void testRemove() {
        ReverseGLLIterator.Node<Integer> node = new ReverseGLLIterator.Node<>(1);
        queue.add(node);
        ReverseGLLIterator.Node<Integer> removedNode = queue.remove();
        assertEquals(1, removedNode.data, "Removed node should have data 1.");
        assertTrue(queue.isEmpty(), "Queue should be empty after removing the only element.");
    }

    @Test
    public void testGetLength() {
        assertEquals(0, queue.getLength(), "New queue should have length 0.");
        queue.add(new ReverseGLLIterator.Node<>(1));
        assertEquals(1, queue.getLength(), "Queue length should be 1 after adding an element.");
        queue.remove();
        assertEquals(0, queue.getLength(), "Queue length should be 0 after removing the element.");
    }

}
