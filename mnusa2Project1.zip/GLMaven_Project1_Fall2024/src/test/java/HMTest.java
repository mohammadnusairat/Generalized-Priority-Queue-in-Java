import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class HMTest {

    private MyHashMap<Integer, String> map;

    @BeforeEach
    public void setUp() {
        map = new MyHashMap<>();
    }

    @Test
    public void testPutAndGet() {
        map.put(1, "One");
        assertEquals("One", map.get(1));
        map.put(1, "Updated One");
        assertEquals("Updated One", map.get(1));
    }

    @Test
    public void testIterator() {
        map.put(1, "One");
        map.put(2, "Two");
        map.put(3, "Three");

        List<String> values = new ArrayList<>();
        for (String value : map) {
            values.add(value);
        }

        assertEquals(3, values.size(), "Iterator should return three values.");
        assertTrue(values.contains("One"));
        assertTrue(values.contains("Two"));
        assertTrue(values.contains("Three"));
    }

    @Test
    public void testGetNonExistentKey() {
        assertNull(map.get(2)); // Expecting null for non-existent key
    }

    @Test
    public void testPutNullValue() {
        map.put(3, null);
        assertNull(map.get(3)); // Expecting null value to be retrievable
    }

    @Test
    public void testSize() {
        assertEquals(0, map.size()); // Should be 0 initially
        map.put(5, "Five");
        assertEquals(1, map.size()); // Should be 1 after adding one element
        map.put(6, "Six");
        assertEquals(2, map.size()); // Should be 2 after adding another element
    }

}
